#include "dealer.h"
#include <iostream>

// ///////////////////////////////////////////////
// C O N S T R U C T O R S / D E S T R U C T O R S
// ///////////////////////////////////////////////

Dealer::Dealer()
{

}

Dealer::~Dealer() { }

// /////////////
// M E T H O D S
// /////////////

void Dealer::shuffle()
{

}
void Dealer::deal()
{

}

void Dealer::exchange()
{

}

void Dealer::determine_winner()
{

}

int main(int argc, char* argv[])
{
	std::cout << "Dealer!" << std::endl;
	return 0;
}
