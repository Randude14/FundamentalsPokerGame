#include "game.h"

// ///////////////////////////////////////////////
// C O N S T R U C T O R S / D E S T R U C T O R S
// ///////////////////////////////////////////////

Game::Game(std::string name)
{
  prize_pot = 0.0;
  current_bet = 1.0;
  game_stage = 0;
}

Game::~Game() { }

// /////////////
// M E T H O D S
// /////////////

void player_join(Player player)
{

}

void check()
{

}

void bet(double amount)
{

}

void call(double amount)
{

}

void raise(double amount)
{

}

void fold()
{

}

void next_stage()
{

}
