#include "player.h"
#include "card.h"


Player::Player()
{
  wallet = 100.0;
  bet_amount = 0.0;
  name = "unknown";
  bet_amount = 0.f;
  has_bet = false;
}

Player::~Player()
{
	
}