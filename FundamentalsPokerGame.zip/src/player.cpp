#include "player.h"
#include "json.hpp"

// ///////////////////////////////////////////////
// C O N S T R U C T O R S / D E S T R U C T O R S
// ///////////////////////////////////////////////

Player::Player()
{
  wallet = 100.0;
  bet_amount = 0.0;
}

Player::~Player() { }

void Player::on_play_click()
{

}

void Player::on_quit_click()
{

}

void Player::on_bet_value_changed()
{

}

void Player::on_check_click()
{

}

void Player::on_bet_click()
{

}

void Player::on_call_click()
{

}

void Player::on_raise_click()
{

}

void Player::on_fold_click()
{

}

void Player::on_discard_click()
{

}
